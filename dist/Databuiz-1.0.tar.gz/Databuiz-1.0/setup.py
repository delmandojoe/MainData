from distutils.core import setup
setup(name ="Databuiz",
      version ="1.0",
      packagees =["Databuiz"])
